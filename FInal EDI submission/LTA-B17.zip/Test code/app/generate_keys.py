import pickle
from pathlib import Path

import streamlit_authenticator as stauth

names=["Shubham Asbe","","Akanksha Lugade","Yash More","Dipali Bhalerao","Anuradha Partudkar"]

usernames=["RBTL21CS001","RBTL21CS002","RBTL21CS003","RBTL21CS005","RBTL21CS010"]

passwords=["RBTL21CS001","RBTL21CS002","RBTL21CS003","RBTL21CS005","RBTL21CS010"]

hashed_passwords= stauth.Hasher(passwords).generate() #Streamlit use bcrypt for hashing the password

file_path=Path(__file__).parent/"hashed_pw.pkl"

with file_path.open("wb") as file:
    pickle.dump(hashed_passwords,file)